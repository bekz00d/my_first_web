<?php

// Подключение к базе данных (замените на свои данные)
require('db_connect.php');

// Функция для очистки данных от SQL-инъекций (не показана здесь для простоты)
function sanitize_input($data) {
  // ... Реализуйте логику очистки ...
  return $data;
}

// Получение данных пользователя из формы
$username = sanitize_input($_POST['username']);
$password = sanitize_input($_POST['password']);
$email = sanitize_input($_POST['email']);

// Хеширование пароля перед хранением
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Проверка (замените на свои требования)
if (strlen($username) < 6) {
  echo "Логин должен быть не менее 6 символов.";
  exit;
}

// Подготовка запроса к базе данных
$sql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $username, $hashed_password, $email);

// Выполнение запроса и обработка ошибок
if ($stmt->execute()) {
  echo "Регистрация прошла успешно! Пожалуйста, проверьте свой email для подтверждения.";
  // Логика отправки письма с подтверждением
} else {
  echo "Произошла ошибка при регистрации. Пожалуйста, попробуйте еще раз.";
}

$stmt->close();
$conn->close();

?>
